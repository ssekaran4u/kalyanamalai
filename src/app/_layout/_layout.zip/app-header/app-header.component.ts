import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './app-header.component.html',
  styleUrls: ['./app-header.component.css']
})
export class AppHeaderComponent implements OnInit {
	isUserMen:boolean = false;
  constructor() { }

  ngOnInit() {
  	if(localStorage.getItem("INkmSet_id"))
  	{
  		this.isUserMen = true;
  	}
  }

}