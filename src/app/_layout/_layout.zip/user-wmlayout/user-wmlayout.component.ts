import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-wmlayout',
  templateUrl: './user-wmlayout.component.html',
  styleUrls: ['./user-wmlayout.component.css']
})
export class UserWmlayoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
