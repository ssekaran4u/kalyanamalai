import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reg-layout',
  templateUrl: './reg-layout.component.html',
  styleUrls: ['./reg-layout.component.css']
})
export class RegLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}