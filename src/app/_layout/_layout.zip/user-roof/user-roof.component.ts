import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-roof',
  templateUrl: './user-roof.component.html',
  styleUrls: ['./user-roof.component.css']
})
export class UserRoofComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
