import { Component, OnInit } from '@angular/core';

@Component({
		selector: 'site-header',
		templateUrl: './site-header.component.html',
		styleUrls: ['./site-header.component.css']
})
export class SiteHeaderComponent implements OnInit {
		constructor() { }
		isUserMen:boolean = false;
		ngOnInit() 
		{ 
			if(localStorage.getItem("INkmSet_id"))
			{
				this.isUserMen = true;
			}
		}

}